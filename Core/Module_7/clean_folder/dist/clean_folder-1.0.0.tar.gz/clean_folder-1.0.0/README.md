#Clean Folder script
Clean folder creates folders: Music, Video, Documents, Books, Images, Archives.
It transliterates all folders and files to latin alphabet and replaces also special signs with "\_"
It sorts all documents in designated folder to above mentioned folders.
All archives will be unpacked.
All empty folders will be deleted.
